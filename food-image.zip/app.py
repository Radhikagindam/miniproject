import os
import requests
import json
import base64
from io import BytesIO
from PIL import Image
from flask import Flask, render_template, request, jsonify, redirect, url_for
from dotenv import load_dotenv
import uuid

# Load environment variables
load_dotenv()

# Get API key from environment variables
MISTRAL_API_KEY = "R64Mwj4jGTDeZcGj6c40v5djcImVfikB"

# Setup Flask app
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload

# Create uploads folder if it doesn't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

def encode_image(image_path):
    """Encode image to base64 string"""
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode('utf-8')

def analyze_food_image(image_path):
    """Analyze food image to detect title, ingredients, and cooking instructions"""
    base64_image = encode_image(image_path)
    
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {MISTRAL_API_KEY}"
    }
    
    # Be more explicit in the prompt about the format we want
    payload = {
        "model": "pixtral-12b-2409",
        "messages": [
            {"role": "system", "content": "You are a culinary expert that analyzes food images. Format your response exactly as follows:\n\nTitle: [Name of the dish]\n\nIngredients:\n- [ingredient 1 with quantity]\n- [ingredient 2 with quantity]\n...\n\nInstructions:\n1. [Step 1]\n2. [Step 2]\n..."},
            {"role": "user", "content": [
                {"type": "text", "text": "Analyze this food image and provide the title, ingredients list with quantities, and cooking instructions."},
                {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{base64_image}"}}
            ]}
        ],
        "temperature": 0.3,
        "max_tokens": 1000
    }
    
    try:
        response = requests.post(
            "https://api.mistral.ai/v1/chat/completions",
            headers=headers,
            json=payload
        )
        
        if response.status_code == 200:
            result = response.json()
            content = result["choices"][0]["message"]["content"]
            
            # Improved parsing logic
            sections = {"title": "", "ingredients": "", "instructions": ""}
            
            # Try multiple patterns for title
            title_patterns = ["Title:", "# ", "##"]
            for pattern in title_patterns:
                if pattern in content:
                    parts = content.split(pattern, 1)
                    if len(parts) > 1:
                        title_line = parts[1].split("\n")[0].strip()
                        sections["title"] = title_line
                        break
            
            # Try multiple patterns for ingredients
            ingredient_patterns = ["Ingredients:", "## Ingredients", "### Ingredients"]
            for pattern in ingredient_patterns:
                if pattern in content:
                    parts = content.split(pattern, 1)
                    if len(parts) > 1:
                        # Extract text until the next section
                        ingredient_text = parts[1]
                        for next_section in ["Instructions:", "## Instructions", "### Instructions"]:
                            if next_section in ingredient_text:
                                ingredient_text = ingredient_text.split(next_section)[0]
                        sections["ingredients"] = ingredient_text.strip()
                        break
            
            # Try multiple patterns for instructions
            instruction_patterns = ["Instructions:", "## Instructions", "### Instructions"]
            for pattern in instruction_patterns:
                if pattern in content:
                    parts = content.split(pattern, 1)
                    if len(parts) > 1:
                        sections["instructions"] = parts[1].strip()
                        break
            
            # If parsing failed, use a more aggressive approach
            if not sections["title"] or not sections["ingredients"] or not sections["instructions"]:
                # Look for any pattern that might indicate a section
                content_lines = content.split("\n")
                current_section = None
                
                for line in content_lines:
                    line = line.strip()
                    if not line:
                        continue
                        
                    # Try to identify sections
                    lower_line = line.lower()
                    if "title" in lower_line or line.startswith("#") and "ingredient" not in lower_line and "instruction" not in lower_line:
                        current_section = "title"
                        sections["title"] = line.replace("Title:", "").replace("#", "").strip()
                    elif "ingredient" in lower_line:
                        current_section = "ingredients"
                        continue
                    elif "instruction" in lower_line or "step" in lower_line:
                        current_section = "instructions"
                        continue
                    elif current_section:
                        sections[current_section] += line + "\n"
            
            # If still empty, provide defaults
            if not sections["title"]:
                sections["title"] = "Detected Food"
            
            # If all parsing failed, return the whole content under ingredients
            if not sections["ingredients"] and not sections["instructions"]:
                sections["ingredients"] = content
            
            return {
                "title": sections["title"],
                "ingredients": sections["ingredients"],
                "instructions": sections["instructions"],
                "raw_content": content
            }
        else:
            return {
                "title": "Error",
                "ingredients": f"Error: {response.status_code}",
                "instructions": response.text,
                "raw_content": f"Error: {response.status_code}\n{response.text}"
            }
    except Exception as e:
        return {
            "title": "Error",
            "ingredients": f"Exception occurred",
            "instructions": str(e),
            "raw_content": f"Exception occurred: {str(e)}"
        }

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'})
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'})
    
    if file:
        # Generate a unique filename
        filename = str(uuid.uuid4()) + os.path.splitext(file.filename)[1]
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        
        # Save the file
        file.save(filepath)
        
        # Analyze food image
        analysis = analyze_food_image(filepath)
        
        # Return the result
        return jsonify({
            'title': analysis['title'],
            'ingredients': analysis['ingredients'],
            'instructions': analysis['instructions'],
            'raw_content': analysis['raw_content'],
            'image_url': url_for('static', filename=f'uploads/{filename}')
        })

@app.route('/save', methods=['POST'])
def save_recipe():
    data = request.get_json()
    title = data.get('title', 'Untitled Recipe')
    ingredients = data.get('ingredients', '')
    instructions = data.get('instructions', '')
    
    if not ingredients and not instructions:
        return jsonify({'status': 'error', 'message': 'No recipe content provided'})
    
    # Generate content for the recipe file
    content = f"# {title}\n\n"
    content += "## Ingredients\n\n"
    content += f"{ingredients}\n\n"
    content += "## Instructions\n\n"
    content += f"{instructions}"
    
    # Generate a unique filename for the recipe file
    filename = f"{title.lower().replace(' ', '_')}_{uuid.uuid4()}.md"
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    
    # Save the recipe
    with open(filepath, 'w') as f:
        f.write(content)
    
    download_url = url_for('static', filename=f'uploads/{filename}')
    
    return jsonify({
        'status': 'success', 
        'message': 'Recipe saved successfully', 
        'download_url': download_url
    })

if __name__ == '__main__':
    app.run(debug=True)